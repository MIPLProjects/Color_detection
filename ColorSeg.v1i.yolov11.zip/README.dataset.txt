# ColorSeg > 2025-07-09 4:31pm
https://universe.roboflow.com/animalhuman-egrlo/colorseg

Provided by a Roboflow user
License: CC BY 4.0

